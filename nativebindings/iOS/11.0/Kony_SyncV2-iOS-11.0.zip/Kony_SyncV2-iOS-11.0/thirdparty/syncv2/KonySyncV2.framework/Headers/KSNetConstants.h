//
//  KSNetConstants.h
//  KonySyncV2
//
//  Created by Girish Lingarajappa Haniyamballi on 30/11/16.
//  Copyright © 2016 Kony. All rights reserved.
//

#import "NetworkError.h"

#ifndef KSNetConstants_h
#define KSNetConstants_h

static const NSInteger NETWORK_ERROR = 6000;
static const NSInteger INVALID_URL = 6001;
static const NSInteger CANNOT_CONNECT_TO_HOST = 6002;
static const NSInteger CANNOT_RESOLVE_HOST = 6003;
static const NSInteger INTERNET_CONNECTIVITY_NOT_AVAILABLE = 6004;
static const NSInteger INVALID_RESPONSE_OBJECT_ERROR_CODE = 6005;
static const NSString *INVALID_RESPONSE_OBJECT_ERROR_MESSAGE = @"Response is either null or not a valid json object";
static const NSInteger INVALID_OPSTATUS_FROM_SERVER = 6006;
static const NSInteger NETWORK_NOT_REACHABLE = 6007;
static const NSString *NETWORK_NOT_REACHABLE_MESSAGE = @"Network not reachable.";

static NSString *const ALLOWABLE_CERTIFICATES = @"allowableCertificates";
static NSString *const ALLOWABLE_CERTIFICATES_ALL = @"all";
static NSString *const ALLOWABLE_CERTIFICATES_BUNDLED = @"bundled";
static NSString *const ALLOWABLE_CERTIFICATES_SYSTEM = @"system";

static NSString *const BACKGROUND_SYNC_ENABLED = @"BackgroundSyncEnabled";
static NSString *const NETWORK_CONNECTION_TIMEOUT = @"networkConnectionTimeout";
static double const NETWORK_DEFAULT_CONNECTION_TIMEOUT = 180.0;
//TODO: Opstatus value needs to be updated from 500100 to 500200, after beta release form server side.
static NSInteger const PARTIAL_SUCCESS_OPSTATUS_MIN_VALUE = 500100;
static NSInteger const PARTIAL_SUCCESS_OPSTATUS_MAX_VALUE = 500200;
static NSInteger const OPSTATUS_SUCCESS = 0;



/**
 options to indicate the allowable certificates

 - KSNetServiceAllowableCertificatesSystem: Default option. allows only https
 - KSNetServiceAllowableCertificatesBundled: TODO: will allow ssl pinning
 - KSNetServiceAllowableCertificatesAll: ignores all certificate errors
 - KSNetServiceAllowableCertificatesDefault: Default maps to System option
 */
typedef NS_ENUM(NSUInteger, KSNetServiceAllowableCertificates) {

    KSNetServiceAllowableCertificatesSystem = 0,
    KSNetServiceAllowableCertificatesBundled,
    KSNetServiceAllowableCertificatesAll,
    KSNetServiceAllowableCertificatesDefault = KSNetServiceAllowableCertificatesSystem

};

/**
 Completion Handler invoked with this values to notify the user with current phase of service request

 - KSNetServicePhaseDidBeginPrepare: Indicates that invoker is preparing the data for service. 
                                     (In upload task, the body data is being written to a file.
 - KSNetServicePhaseDidEndPrepare: Service invoker has completed the data preperation.
 - KSNetServicePhaseDidBeginRequest: Service invoker has issues a network request.
 - KSNetServicePhaseDidEndRequest: Serice invoker has completed the network request.
 */
typedef NS_ENUM(NSUInteger, KSNetServicePhase) {

    KSNetServicePhaseDidBeginPrepare = 0,
    KSNetServicePhaseDidEndPrepare,
    KSNetServicePhaseDidBeginRequest,
    KSNetServicePhaseDidEndRequest

};

/* Completion handler signature */
typedef void (^KSNetworkCompletionHandler)(NSData *data,NSHTTPURLResponse *response, KSNetServicePhase servicePhase, NetworkError *error);

#endif /* KSNetConstants_h */
